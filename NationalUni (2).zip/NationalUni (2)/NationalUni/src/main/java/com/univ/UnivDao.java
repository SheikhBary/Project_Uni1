package com.univ;

import java.util.*;
import java.sql.*;

public class UnivDao {

	public static Connection getConnection() {
		Connection con=null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/university?serverTimezone=UTC&useSSL=false","root","root");	
			
		}catch(Exception e){
			System.out.println(e);
		}
		return con;
	}


	public static Admin authenticateAdmin(String adminEmail, String adminPass)
	{
		Admin a = new Admin();

		try
		{
			Connection con =UnivDao.getConnection();
			PreparedStatement st=con.prepareStatement("select * from Univ_Admin where lower(Admin_Email)=? and Admin_Password=?");			
			st.setString(1, adminEmail.toLowerCase());
			st.setString(2, adminPass);
			ResultSet rs=st.executeQuery();
			
			if (rs.next()){
				a.setId(rs.getInt(1));
				a.setName(rs.getString(2));
				a.setEmail(rs.getString(3));
			}
			con.close();
		}catch(Exception ex) {
			System.out.println(ex);	
			
		}
		return a;
		
	}

	public static Accountant authenticateAccountant(String accEmail, String accPass)
	{
		Accountant a = new Accountant();

		try
		{
			Connection con =UnivDao.getConnection();
			PreparedStatement st=con.prepareStatement("select acc.Acc_Id, acc.Acc_Email, acc.Acc_First_Name, acc.Acc_Last_Name, acc.Acc_Phone, dep.Dept_Id, dep.Dept_Name "
					+ " from UNIV_ACCOUNTANT acc, Univ_Department dep "
					+ " where acc.FK_Dept_Id=dep.Dept_ID and acc.IsActive='Y' and lower(acc.Acc_Email)=? and acc.Acc_Password=?");			

			st.setString(1, accEmail.toLowerCase());
			st.setString(2, accPass);
			ResultSet rs=st.executeQuery();
			
			if (rs.next()){
				a.setId(rs.getInt(1));
				a.setEmail(rs.getString(2));
				a.setFirstName(rs.getString(3));
				a.setLastName(rs.getString(4));
				a.setPhone(rs.getInt(5));
				a.setDeptId(rs.getInt(6));
				a.setDeptName(rs.getString(7));
			}
			con.close();
		}catch(Exception ex) {
			System.out.println(ex);
			
		}
		return a;
		
	}
	
	public static int createAccountant(Accountant acct)
	{
		int status=0;
		try {
			Connection con = UnivDao.getConnection();
			PreparedStatement st=con.prepareStatement("insert into UNIV_ACCOUNTANT "
					+ "(Acc_Email, Acc_Password, Acc_First_Name, Acc_Last_Name, Acc_Phone, IsActive, FK_Dept_Id) "
					+ "values(?,?,?,?,?,?,?)");
			
			st.setString(1,acct.getEmail());
			st.setString(2,"abc123"); //default password
			st.setString(3,acct.getFirstName());
			st.setString(4,acct.getLastName());
			st.setInt(5,acct.getPhone());
			st.setString(6,"Y");
			st.setInt(7,acct.getDeptId());

			status=st.executeUpdate();
			con.close();
			
		}catch(Exception e){
			System.out.println(e);
		}
		return status;
	}

	public static int updateAccountant(Accountant acct)
	{
	
		int status=0;
		try {
			Connection con =UnivDao.getConnection();
			PreparedStatement st=con.prepareStatement("update UNIV_ACCOUNTANT set Acc_First_Name=?, Acc_Last_Name=?, Acc_Phone=?, FK_Dept_Id=? where Acc_Id=?");
			
			st.setString(1,acct.getFirstName());
			st.setString(2,acct.getLastName());
			st.setInt(3,acct.getPhone());
			st.setInt(4,acct.getDeptId());
			st.setInt(5,acct.getId());
			
			status=st.executeUpdate();
			con.close();
			
		}catch(Exception e){
			System.out.println(e);
		}
		return status;
	}
	



	public static int deleteAccountant(int accId)
	{
		int status=0;
		try
		{
			Connection con =UnivDao.getConnection();
			PreparedStatement st=con.prepareStatement("update UNIV_ACCOUNTANT set IsActive='N' where Acc_Id=?");

			st.setInt(1,accId);
			
			status=st.executeUpdate();
			con.close();
			
		}catch(Exception e) {
			System.out.println(e);
			
		}
		return status;
		
	}
	

	public static Accountant getAccountantByID(int accId)
	{
		Accountant a = new Accountant();

		try
		{
			Connection con =UnivDao.getConnection();
			PreparedStatement st=con.prepareStatement("select acc.Acc_Id, acc.Acc_Email, acc.Acc_First_Name, acc.Acc_Last_Name, acc.Acc_Phone, dep.Dept_Id, dep.Dept_Name "
					+ " from UNIV_ACCOUNTANT acc, Univ_Department dep "
					+ " where acc.FK_Dept_Id=dep.Dept_Id and acc.IsActive='Y' and acc.Acc_Id=?");			
			st.setInt(1, accId);
			ResultSet rs=st.executeQuery();
			
			if (rs.next()){
				a.setId(rs.getInt(1));
				a.setEmail(rs.getString(2));
				a.setFirstName(rs.getString(3));
				a.setLastName(rs.getString(4));
				a.setPhone(rs.getInt(5));
				a.setDeptId(rs.getInt(6));
				a.setDeptName(rs.getString(7));
			}
			con.close();
		}catch(Exception ex) {
			System.out.println(ex);
			
		}
		return a;
		
	}
	
	public static List<Accountant> getAllAccountants()
	{
		List<Accountant> accountants = new ArrayList<Accountant>();

		try
		{
			Connection con =UnivDao.getConnection();
			PreparedStatement st=con.prepareStatement("select acc.Acc_Id, acc.Acc_Email, acc.Acc_First_Name, acc.Acc_Last_Name, acc.Acc_Phone, dep.Dept_Id, dep.Dept_Name "
					+ " from UNIV_ACCOUNTANT acc, Univ_Department dep "
					+ " where acc.FK_Dept_Id=dep.Dept_Id and acc.IsActive='Y' ");			
			ResultSet rs=st.executeQuery();
			
			while (rs.next()){
				Accountant a= new Accountant();
				a.setId(rs.getInt(1));
				a.setEmail(rs.getString(2));
				a.setFirstName(rs.getString(3));
				a.setLastName(rs.getString(4));
				a.setPhone(rs.getInt(5));
				a.setDeptId(rs.getInt(6));
				a.setDeptName(rs.getString(7));
				accountants.add(a);
			}
			
			con.close();
		}catch(Exception ex) {
			System.out.println(ex);
		}
		return accountants;
		
	}

	public static List<Department> getAllDepartments()
	{
		List<Department> departments = new ArrayList<Department>();

		try
		{
			Connection con =UnivDao.getConnection();
			PreparedStatement st=con.prepareStatement("select * from Univ_Department dep order by Dept_Name");			
			ResultSet rs=st.executeQuery();
			
			while (rs.next()){
				Department d= new Department();
				d.setId(rs.getInt(1));
				d.setName(rs.getString(2));
				departments.add(d);
			}
			
			con.close();
		}catch(Exception ex) {
			System.out.println(ex);
		}
		return departments;
		
	}

}


	

